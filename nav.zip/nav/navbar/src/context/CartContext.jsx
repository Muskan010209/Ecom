import { createContext } from 'react';

// Create the CartContext
export const CartContext = createContext();
