// src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';

import CartProvider from './context/CartProvider';

import Navbar from './components/Navbar';
import Home from './components/Home';
import About from './components/About';
import Products from './components/Products';
import Contact from './components/Contact';
import Cart from './components/Cart';
import Checkout from './components/Checkout';
import Register from './components/Register';
import Login from './components/Login';
import Logout from './components/Logout';

const stripePromise = loadStripe('STRIPE_PUBLISHABLE_KEY');

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <CartProvider>
      <Router>
        <Navbar isAuthenticated={isAuthenticated} onLogout={() => setIsAuthenticated(false)} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/products" element={<Products />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" 
                 element={
                   isAuthenticated ? (
                     <Elements stripe={stripePromise}>
                       <Checkout />
                     </Elements>
                   ) : (
                     <Login onLogin={() => setIsAuthenticated(true)} />
                   )
                 } 
          />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login onLogin={() => setIsAuthenticated(true)} />} />
        </Routes>
      </Router>
    </CartProvider>
  );
};

export default App;
