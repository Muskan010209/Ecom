import React, { useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { CartContext } from '../context/CartContext'; 

const Navbar = ({ isAuthenticated, onLogout }) => { 
  const [isOpen, setIsopen] = useState(false);
  const { cartCount } = useContext(CartContext); 

  const toggleMenu = () => {
    setIsopen(!isOpen);
  };

  return (
    <nav className="navbar">
      <div className="brand">
        <Link to="/" className="logo">Fashionista</Link>
      </div>
      <div className={`menu-icon ${isOpen ? "open" : ""}`} onClick={toggleMenu}>
        <div className="bar"></div>
        <div className="bar"></div>
        <div className="bar"></div>
      </div>
      <ul className={`navbar-links ${isOpen ? "active" : ""}`}>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/about">About</Link></li>
        <li><Link to="/products">Products</Link></li>
        <li><Link to="/contact">Contact</Link></li>
        
        <li><Link to="/cart" className="cart-icon">
          <i className="fas fa-shopping-cart"></i>
          {cartCount > 0 && <span className="cart-quantity">{cartCount}</span>}
        </Link></li>
        {isAuthenticated ? (
          <>
            <li><Link to="/checkout">Checkout</Link></li>
            <li><button onClick={onLogout}>Logout</button></li>
          </>
        ) : (
          <>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/register">Register</Link></li>
          </>
        )}
      </ul>
    </nav>
  );
};

export default Navbar;
