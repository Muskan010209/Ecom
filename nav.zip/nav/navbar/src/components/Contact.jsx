import React from 'react';
import './Contact.css';

const Contact = () => {
  return (
    <div className="contact-page">
      {/* Contact Form Section */}
      <div className="contact-form-section">
        <h1>Contact Us</h1>
        <form className="contact-form">
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input type="text" id="name" name="name" placeholder="Your Name" required />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Your Email" required />
          </div>
          <div className="form-group">
            <label htmlFor="message">Message</label>
            <textarea id="message" name="message" placeholder="Your Message" rows="5" required></textarea>
          </div>
          <button type="submit" className="submit-button">Send Message</button>
        </form>
      </div>

      {/* Company Info Section */}
      <div className="company-info-section">
        <h2>Our Office</h2>
        <p>123 Main Street, Anytown, USA</p>
        <p>Email: contact@company.com</p>
        <p>Phone: (123) 456-7890</p>
      </div>

      {/* Map Section */}
      <div className="map-section">
        <h2>Find Us Here</h2>
        <img src="https://via.placeholder.com/600x300" alt="Map Location" />
      </div>
    </div>
  );
};

export default Contact;
