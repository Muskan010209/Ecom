import React from 'react'
import Products from './Products'
import About from './About'
import Footer from './Footer'

const Home = () => {
  return (
    <div>
            <About/>

      <Products/>
      <Footer/>

    </div>
  )
}

export default Home