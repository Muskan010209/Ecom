import React, { useContext, useState } from 'react';
import axios from 'axios';
import { CartContext } from '../context/CartContext';
import './Checkout.css';

const ShippingInfo = ({ shippingInfo, handleInputChange }) => (
    <div className="shipping-info">
        <h2>Shipping Information</h2>
        <div className="form-group">
            <label>Name:</label>
            <input type="text" name="name" value={shippingInfo.name} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
            <label>Address:</label>
            <input type="text" name="address" value={shippingInfo.address} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
            <label>City:</label>
            <input type="text" name="city" value={shippingInfo.city} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
            <label>Postal Code:</label>
            <input type="text" name="postalCode" value={shippingInfo.postalCode} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
            <label>Country:</label>
            <select name="country" value={shippingInfo.country} onChange={handleInputChange} required>
                <option value="">Select Country</option>
                <option value="US">United States</option>
                <option value="CA">Canada</option>
                <option value="UK">United Kingdom</option>
            </select>
        </div>
        <div className="form-group">
            <label>State:</label>
            <select name="state" value={shippingInfo.state} onChange={handleInputChange} required>
                <option value="">Select State</option>
                <option value="CA">California</option>
                <option value="TX">Texas</option>
                <option value="NY">New York</option>
            </select>
        </div>
    </div>
);

const PaymentInfo = ({ paymentInfo, handleInputChange }) => (
    <div className="payment-info">
        <h2>Payment Information</h2>
        <div className="form-group">
            <label>Credit Card Number:</label>
            <input type="text" name="cardNumber" value={paymentInfo.cardNumber} placeholder="1234 5678 9012 3456" onChange={handleInputChange} required />
        </div>
        <div className="form-group">
            <label>Expiration Date:</label>
            <input type="text" name="expiry" value={paymentInfo.expiry} placeholder="MM/YY" onChange={handleInputChange} required />
        </div>
        <div className="form-group">
            <label>CVV:</label>
            <input type="text" name="cvv" value={paymentInfo.cvv} placeholder="123" onChange={handleInputChange} required />
        </div>
    </div>
);

const Checkout = () => {
    const { cart, clearCart } = useContext(CartContext);
    const [shippingInfo, setShippingInfo] = useState({
        name: '',
        address: '',
        city: '',
        postalCode: '',
        country: '',
        state: '',
    });
    const [paymentInfo, setPaymentInfo] = useState({
        cardNumber: '',
        expiry: '',
        cvv: ''
    });

    const totalPrice = cart.reduce((total, product) => total + product.price, 0);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (name in shippingInfo) {
            setShippingInfo({
                ...shippingInfo,
                [name]: value,
            });
        } else {
            setPaymentInfo({
                ...paymentInfo,
                [name]: value,
            });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const orderData = {
            shippingInfo,
            cart,
            totalPrice,
        };

        try {
            const response = await axios.post('http://localhost:5000/api/orders', orderData, {
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            alert('Order placed successfully!');
            clearCart();  
        } catch (error) {
            console.error('There was an error placing the order!', error);
            alert('Failed to place order: ' + error.response?.data.message || error.message);
        }
    };

    return (
        <div className="checkout-container">
            <h1>Checkout</h1>
            <div className="checkout-summary">
                <h2>Order Summary</h2>
                <ul>
                    {cart.map((product, index) => (
                        <li key={index} className="checkout-item">
                            <img src={product.images[0]} alt={product.title} style={{ width: '50px', height: '50px' }} />
                            <div>
                                <p>{product.title}</p>
                                <p>${product.price}</p>
                            </div>
                        </li>
                    ))}
                </ul>
                <h3>Total: ${totalPrice.toFixed(2)}</h3>
            </div>

            <form onSubmit={handleSubmit}>
                <ShippingInfo shippingInfo={shippingInfo} handleInputChange={handleInputChange} />
                <PaymentInfo paymentInfo={paymentInfo} handleInputChange={handleInputChange} />
                <div className="form-group">
                    <label>Or Pay with:</label>
                    <button type="button" className="paypal-button">PayPal</button>
                </div>
                <button type="submit" className="checkout-button">Place Order</button>
            </form>
        </div>
    );
};

export default Checkout;
