import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import './Product.css';
import { CartContext } from '../context/CartContext';

const Products = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { addToCart } = useContext(CartContext);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const response = await axios.get('https://api.escuelajs.co/api/v1/products');
                setData(response.data);
            } catch (error) {
                setError(error.message);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
        <div>
            <h1 className='heading'>Products</h1>
            <ul className="product-list">
                {data.map(product => (
                    <li key={product.id} className="product-item">
                        <img src={product.images[0]} alt={product.title} style={{ width: '200px', height: '200px' }} />
                        <h2>{product.title}</h2>
                        <p>${product.price}</p>
                        <button onClick={() => addToCart(product)}>Add to Cart</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Products;
