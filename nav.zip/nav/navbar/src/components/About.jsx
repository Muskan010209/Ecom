import React from 'react';
import './About.css';

const About = () => {
  return (
    <div className="about-page">
      {/* Hero Section */}
      <div className="hero-section">
        <h1>About Us</h1>
        <p>Your satisfaction is our priority</p>
      </div>

      {/* Mission Section */}
      <div className="mission-section">
        <h2>Our Mission</h2>
        <p>
          We strive to deliver the best products and services to our customers, ensuring that
          quality and satisfaction are always at the forefront of our efforts. Our team is
          dedicated to continuous improvement, innovation, and customer care.
        </p>
      </div>
    </div>
  );
};

export default About;
