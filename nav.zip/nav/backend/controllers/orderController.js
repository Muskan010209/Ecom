const Order = require('../models/order');

exports.createOrder = async (req, res, next) => {
    try {
        const { shippingInfo, cart, totalPrice } = req.body;

        const newOrder = new Order({
            shippingInfo,
            cart,
            totalPrice,
        });

        const savedOrder = await newOrder.save();
        res.status(201).json({ success: true, data: savedOrder });
    } catch (error) {
        next(error);
    }
};
