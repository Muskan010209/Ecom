const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.createPaymentIntent = async (req, res) => {
    try {
        const { totalPrice } = req.body; // Get totalPrice from the frontend

        // Calculate the amount in cents
        const amount = Math.round(totalPrice * 100); // Convert dollars to cents

        const paymentIntent = await stripe.paymentIntents.create({
            amount,
            currency: 'usd',
            automatic_payment_methods: {
                enabled: true,
            },
        });

        res.status(200).json({
            clientSecret: paymentIntent.client_secret,
        });
    } catch (error) {
        res.status(500).json({ message: 'Payment failed', error });
    }
};
